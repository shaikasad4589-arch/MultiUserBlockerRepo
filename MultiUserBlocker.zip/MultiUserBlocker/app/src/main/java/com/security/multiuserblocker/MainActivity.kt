package com.security.multiuserblocker

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BroadcastReceiver
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.util.Log

class MainActivity : AppCompatActivity() {

    private lateinit var statusTextView: TextView
    private lateinit var enableBlockerButton: Button
    private lateinit var statusIndicator: TextView
    private lateinit var dpm: DevicePolicyManager
    private lateinit var adminComponent: ComponentName
    private val blockingReceiver = BlockingReceiver()

    private val deviceAdminLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            Log.d("MainActivity", "Device Admin enabled successfully")
            statusTextView.text = "✓ DEVICE ADMIN ACTIVATED\n✓ MONITORING SERVICE RUNNING\n✓ MULTIPLE USERS BLOCKED"
            statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
            enableBlockerButton.text = "PROTECTION ACTIVE"
            enableBlockerButton.isEnabled = false
            startMonitoringService()
        } else {
            Toast.makeText(this, "Device Admin activation failed", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, DeviceAdminReceiver::class.java)

        statusTextView = findViewById(R.id.statusTextView)
        enableBlockerButton = findViewById(R.id.enableBlockerButton)
        statusIndicator = findViewById(R.id.statusIndicator)

        updateStatus()

        enableBlockerButton.setOnClickListener {
            requestDeviceAdmin()
        }

        // Register broadcast receiver
        val filter = IntentFilter(MonitoringService.ACTION_MULTIPLE_USERS_BLOCKED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(blockingReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(blockingReceiver, filter)
        }

        // Start monitoring immediately
        startMonitoringService()
    }

    private fun requestDeviceAdmin() {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
        intent.putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "MultiUserBlocker needs Device Admin to prevent unauthorized user account creation and protect your device"
        )
        deviceAdminLauncher.launch(intent)
    }

    private fun startMonitoringService() {
        val serviceIntent = Intent(this, MonitoringService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun updateStatus() {
        val isAdminActive = dpm.isAdminActive(adminComponent)
        val isMultipleUsersDisabled = !isMultipleUsersEnabled()

        if (isAdminActive && isMultipleUsersDisabled) {
            statusTextView.text = "✓ PROTECTION ACTIVE\n✓ MULTIPLE USERS: BLOCKED\n✓ AUTO-MONITORING: ON"
            statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
            statusIndicator.text = "🔒 SECURED"
            enableBlockerButton.isEnabled = false
            enableBlockerButton.text = "PROTECTION ACTIVE"
        } else if (isAdminActive) {
            statusTextView.text = "⚠ Admin active, enabling monitoring...\n✓ MULTIPLE USERS: BLOCKED"
            statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_dark))
            statusIndicator.text = "⚙️ ACTIVATING"
            startMonitoringService()
        } else {
            statusTextView.text = "⚠ PROTECTION INACTIVE\n✓ Tap button to activate\n✓ Multiple users can be enabled"
            statusTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
            statusIndicator.text = "🔓 UNPROTECTED"
            enableBlockerButton.isEnabled = true
            enableBlockerButton.text = "ACTIVATE PROTECTION"
        }
    }

    private fun isMultipleUsersEnabled(): Boolean {
        return try {
            Settings.Global.getInt(contentResolver, "guest_user_enabled", 0) == 1 ||
            Settings.Secure.getInt(contentResolver, "allow_multiple_users", 1) == 1
        } catch (e: Exception) {
            false
        }
    }

    inner class BlockingReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == MonitoringService.ACTION_MULTIPLE_USERS_BLOCKED) {
                Log.i("MainActivity", "Multiple users blocking triggered")
                Toast.makeText(
                    this@MainActivity,
                    "⚠️ Unauthorized attempt detected and blocked",
                    Toast.LENGTH_SHORT
                ).show()
                updateStatus()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(blockingReceiver)
        } catch (e: Exception) {
            Log.e("MainActivity", "Error unregistering receiver: ${e.message}")
        }
    }
}
