package com.security.multiuserblocker

import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.os.BroadcastReceiver
import android.os.Context
import android.os.Handler
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class MonitoringService : Service() {

    private val handler = Handler()
    private val checkInterval = 5000L // Check every 5 seconds

    override fun onCreate() {
        super.onCreate()
        Log.d("MonitoringService", "Service created")
        schedulePeriodicCheck()
    }

    private fun schedulePeriodicCheck() {
        handler.postDelayed({
            checkAndBlockMultipleUsers()
            schedulePeriodicCheck()
        }, checkInterval)
    }

    private fun checkAndBlockMultipleUsers() {
        try {
            // Check if guest user is enabled
            val guestUserEnabled = Settings.Global.getInt(
                contentResolver,
                "guest_user_enabled",
                0
            ) == 1

            // Check if secondary users setting is enabled
            val secondaryUsersAllowed = Settings.Secure.getInt(
                contentResolver,
                "allow_multiple_users",
                1
            ) == 1

            if (guestUserEnabled || secondaryUsersAllowed) {
                Log.w("MonitoringService", "Multiple users detected - blocking")
                blockMultipleUsers()
            }
        } catch (e: Exception) {
            Log.e("MonitoringService", "Error checking settings: ${e.message}")
        }
    }

    private fun blockMultipleUsers() {
        try {
            // Disable guest user
            Settings.Global.putInt(
                contentResolver,
                "guest_user_enabled",
                0
            )

            // Disable secondary users
            Settings.Secure.putInt(
                contentResolver,
                "allow_multiple_users",
                0
            )

            Log.i("MonitoringService", "Multiple users disabled successfully")
            sendBlockNotification()
        } catch (e: Exception) {
            Log.e("MonitoringService", "Error blocking multiple users: ${e.message}")
        }
    }

    private fun sendBlockNotification() {
        // Send notification that blocking was triggered
        val notificationIntent = Intent(ACTION_MULTIPLE_USERS_BLOCKED)
        sendBroadcast(notificationIntent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("MonitoringService", "Service started")
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("MonitoringService", "Service destroyed - attempting restart")
        // Try to restart service
        val intent = Intent(this, MonitoringService::class.java)
        startService(intent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_MULTIPLE_USERS_BLOCKED = "com.security.multiuserblocker.MULTIPLE_USERS_BLOCKED"
    }
}

class BlockingWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        try {
            val contentResolver = applicationContext.contentResolver
            Settings.Global.putInt(contentResolver, "guest_user_enabled", 0)
            Settings.Secure.putInt(contentResolver, "allow_multiple_users", 0)
            Log.i("BlockingWorker", "Multiple users blocked successfully")
            return Result.success()
        } catch (e: Exception) {
            Log.e("BlockingWorker", "Error: ${e.message}")
            return Result.retry()
        }
    }
}
