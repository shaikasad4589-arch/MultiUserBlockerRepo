package com.security.multiuserblocker

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log

class DeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(intent)
        Log.d("DeviceAdmin", "Device Admin enabled")
        // Start monitoring service
        val serviceIntent = Intent(context, MonitoringService::class.java)
        context.startService(serviceIntent)
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(intent)
        Log.d("DeviceAdmin", "Device Admin disabled - attempting to re-enable")
        // Try to re-enable itself
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, DeviceAdminReceiver::class.java)
        try {
            dpm.setActiveAdmin(admin, true)
        } catch (e: Exception) {
            Log.e("DeviceAdmin", "Failed to re-enable: ${e.message}")
        }
    }

    override fun onPasswordChanged(context: Context, intent: Intent) {
        super.onPasswordChanged(intent)
        Log.d("DeviceAdmin", "Password changed")
    }
}
